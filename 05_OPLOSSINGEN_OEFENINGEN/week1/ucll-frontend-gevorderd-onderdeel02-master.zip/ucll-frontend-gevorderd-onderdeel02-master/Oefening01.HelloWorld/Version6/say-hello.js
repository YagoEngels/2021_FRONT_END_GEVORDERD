document.getElementById("sayHelloButton").addEventListener("click", function() {
    document.getElementById("sayHelloInput").value = "Hello world!";
});