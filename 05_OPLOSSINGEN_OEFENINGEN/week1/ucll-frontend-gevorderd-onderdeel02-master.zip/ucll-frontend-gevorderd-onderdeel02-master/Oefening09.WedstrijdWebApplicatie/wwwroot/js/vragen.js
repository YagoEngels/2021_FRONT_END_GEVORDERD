﻿document.querySelector("form").addEventListener("submit", function (e) {
    window.location.href = "contact.html";
    e.preventDefault();
});