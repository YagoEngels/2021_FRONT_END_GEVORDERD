let allButtons = document.getElementsByTagName("button");
let allInpts = document.getElementsByTagName("input");

for(let i = 0 ; i < allButtons.length ; i ++){
    allButtons[i].addEventListener("click" , (e) =>{
        let aantaluren = allInpts[i].value;
        aantaluren++;
        allInpts[i].value = aantaluren;
    });
};