﻿document.getElementById("helloButton").addEventListener("click", function () {
    document.getElementById("helloInput").value = "Hello World!";
});