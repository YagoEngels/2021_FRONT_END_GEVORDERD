export class ToDoObject {
    constructor(titel,toegewezenPersoon,deadLine,afgewerkt,description){
        this._titel = titel;
        this._toegewezenPersoon = toegewezenPersoon;
        this._deadLine = deadLine;
        this._afgewerkt = afgewerkt;
        this._description = description;
    }

    get titel(){
        return this._titel;
    }

    get toegewezenPersoon(){
        return this._toegewezenPersoon;
    }

    get deadLine(){
        return this._deadLine;
    }

    get afgewerkt(){
        return this._afgewerkt;
    }

    get description(){
        return this._description;
    }
}