import './file1';
console.log("Hello World!");