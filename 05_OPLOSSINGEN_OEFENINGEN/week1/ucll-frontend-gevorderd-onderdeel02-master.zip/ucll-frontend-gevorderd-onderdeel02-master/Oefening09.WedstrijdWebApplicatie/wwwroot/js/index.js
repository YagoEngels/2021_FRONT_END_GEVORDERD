﻿document.getElementById("deelnemen").addEventListener("click", function (e) {
    window.location.href = "vragen.html";
});