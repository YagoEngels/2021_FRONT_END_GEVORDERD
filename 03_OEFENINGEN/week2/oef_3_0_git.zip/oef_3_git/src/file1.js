import "./file";
alert("lollll");