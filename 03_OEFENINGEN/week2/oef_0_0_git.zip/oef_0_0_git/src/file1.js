//dit is de meest belangrijke som van u leven biatch 
let som = 1+1;