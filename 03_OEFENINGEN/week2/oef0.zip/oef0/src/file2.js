import "./file1";

alert("hello worlddddd lol update i guess");