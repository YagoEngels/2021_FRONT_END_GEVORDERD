let rn = Math.floor(Math.random(10) * 10);
console.log(rn);
document.getElementById("randomNr").innerHTML = rn;
let aantal = 1;
const feedback = document.getElementById("result");
function clickTheBtn(){
    let nummer = document.getElementById("Kies").value;

    if(nummer == rn){
        feedback.innerHTML = "Je was Juist met het getal " + nummer + " in dit aantal beurten aanta : " + aantal;
        feedback.className = "alert alert-info";
        feedback.style.display = "block";
        document.getElementById("play").style.display = "block";
    } else {
        if(nummer > rn){
            feedback.innerHTML = "Je was fout met het getal " + nummer + " zoek het wat lager";
            feedback.className = "alert alert-danger";
            feedback.style.display = "block";
            aantal ++;
        } else {
            feedback.innerHTML = "Je was fout met het getal " + nummer + " zoek het wat hoger";
            feedback.className = "alert alert-danger";
            feedback.style.display = "block";
            aantal ++;
        }
    }
}

document.getElementById("button").addEventListener("click", function(event){
    clickTheBtn();
    event.preventDefault();
});

document.getElementById("play").addEventListener("click", function(){
    rn = Math.floor(Math.random(10) * 10);
    aantal = 1;
    document.getElementById("Kies").value = "";
    feedback.style.display = "none";
    feedback.innerHTML = "";
    document.getElementById("play").style.display = "none";
});