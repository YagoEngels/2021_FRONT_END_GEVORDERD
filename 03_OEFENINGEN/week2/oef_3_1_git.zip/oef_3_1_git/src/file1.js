let output = document.getElementsByTagName("textarea")[0];

output.value += "helo from file1";