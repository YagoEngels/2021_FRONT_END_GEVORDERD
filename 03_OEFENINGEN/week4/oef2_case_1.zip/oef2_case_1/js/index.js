const form = document.querySelector("form");
const tbodyElement = document.querySelector("tbody");
const key = "138508ab8cc24d1afb1043f5efff26c6";


form.addEventListener("submit", async (e) => {
    e.preventDefault();
    let stad = document.getElementById("stad").value;
    //falsy = 0;"";undefiend;null
    if(stad){
        let url = `https://api.openweathermap.org/data/2.5/forecast?q=${stad}&appid=${key}`
        //betere manier 
        try {
            let response = await fetch(url);
            let weatherForecast = await response.json();

            for(let i = 0 ; i < weatherForecast.list.length ; i++){
                let weatherForecastVoorTijdstip = weatherForecast.list[i];

                let datum = new Date(weatherForecastVoorTijdstip.dt * 1000);
                let temperatuur = weatherForecastVoorTijdstip.main.temp - 273.15;
                let weer = weatherForecastVoorTijdstip.weather[0].description;

                let row = document.createElement("tr");
                if(temperatuur < 2){
                    row.classList.add("table-info");
                }
                row.innerHTML = `
                <td>${datum.toLocaleDateString()} - ${datum.toLocaleTimeString()}</td>
                <td>${temperatuur.toFixed(1)}</td>
                <td>${weer}</td>
                `
                tbodyElement.appendChild(row);
            }

        } catch (error){
            console.log(error);
        }
    }
});