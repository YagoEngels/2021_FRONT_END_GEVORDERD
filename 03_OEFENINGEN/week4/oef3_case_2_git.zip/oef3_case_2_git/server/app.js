import ChatMessage from "./../shared/chat-message.js";
import express from "express";
import body from "body-parser";
const app = express();
const port = 3000;

let messages = [new ChatMessage("system","hello from server. Started on " + new Date().toISOString() + ".")];

app.use(express.static("../client/public"));
app.use(body.json());

app.get("/api/chat",(req,res) => {
    res.json(messages);
});

app.post("/api/chat",(req,res) =>{
    //console.log(req,body);
    messages.push(new ChatMessage(req.body._nickname, req.body._message));
    res.json({aantalberichten: messages.length});
    res.status(200).end();
})

app.listen(port, function(){
    console.log(`server luisterd op poort ${port}`);
})
