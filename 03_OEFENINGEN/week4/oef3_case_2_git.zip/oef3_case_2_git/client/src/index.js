const formElement = document.querySelector("form");
const textareaElement = document.querySelector("textarea");
const errorElement = document.getElementById("error");
const nicknameElement = document.getElementById("nickname");
const messageElement = document.getElementById("message");
import { ChatMessage } from "../../shared/chat-message";

function getMessages(){
    fetch("/api/chat")
        .then((response) => {
            return response.json();
        })
        .then((messages) => {
            let chatBericht = "";
            for(let i = 0 ; i < messages.length; i++){
                chatBericht += (messages[i]._nickname + " : " + messages[i]._message + "\n");
            }

            textareaElement.value = chatBericht;
        })
        .catch ((error) => {
            errorselement.innerText = error;
        })
}
setInterval(getMessages,1000);

formElement.addEventListener("submit" ,async (e) => {
    e.preventDefault();


    try{
        let message = new ChatMessage (nicknameElement.value,messageElement.value)

        await  fetch("api/chat", {
            method: "POST",
            headers: {
                'Content-Type' : 'application/json'
            },
            body: JSON.stringify(message)
        });

        let chatrespone = await response.JSON();
    } catch (error){
        console.log(error);
    }
});