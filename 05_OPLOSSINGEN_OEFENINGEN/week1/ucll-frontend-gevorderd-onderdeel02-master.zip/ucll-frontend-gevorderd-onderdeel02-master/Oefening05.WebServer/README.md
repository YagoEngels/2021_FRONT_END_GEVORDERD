﻿Dit is een 'hybride' oplossing: je kan deze oplossing zowel uitvoeren in NodeJS als in ASP.NET Core.

# Uitvoeren met NodeJs
1. Zorg ervoor dat NodeJS geïnstalleerd is.
2. ```npm install``` (dit installeert de 'express' dependency)
2. ```node app.js```
3. Ga naar http://localhost:3000

# Uitvoeren met ASP.NET Core
1. Zorg ervoor dat .NET SDK 5.0 geïnstalleerd is.
2. ```dotnet build```
2. ```dotnet run```
3. Ga naar https://localhost:5001 (of http://localhost:5000)

