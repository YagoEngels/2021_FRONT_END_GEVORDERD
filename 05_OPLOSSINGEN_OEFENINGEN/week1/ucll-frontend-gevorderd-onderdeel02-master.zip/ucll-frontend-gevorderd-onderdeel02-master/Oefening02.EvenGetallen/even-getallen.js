// Met document.getElementById() halen we een element op, op basis van het ID.
// Vervolgens 'onthouden' we dat element door het in een constante te steken.
const getalInput = document.getElementById("getal");
const boodschapSpan = document.getElementById("boodschap");

// Een input biedt heel wat events aan, zoals 'input' en 'change'. 
// 'input' gaat direct af bij elke verandering in het input veld, 'change' gaat enkel af wanneer je het input veld verlaat.
// Voor deze oefeninge is het 'input' event beter.
getalInput.addEventListener("input", function() {    
    // % is de modulo operator: het berekent de rest bij deling.
    // Een getal is uiteraard even als het deelbaar is door 2 (rest is dan 0).
    if (getalInput.value % 2 === 0) {
        boodschapSpan.innerText = "Het getal is even";
        // We hadden hier ook direct de style van de span kunnen aanpassen via 'style':
        // Vb: boodschapSpan.style.color = "green"; 
        // Maar dat is minder clean: alle beslissingen over de stijl zouden in het CSS bestand moeten staan.
        // Vandaar werd er geopteerd om een CSS class te definieren die we dan hier op het element zetten via className.
        // Zo kan een web designer later beslissen om de kleur aan te passen en moeten wij onze code niet aanraken.
        boodschapSpan.className = "even";
    } else {
        boodschapSpan.className = "oneven";
        boodschapSpan.innerText = "Het getal is oneven";
    }
});