export class winkelItem{
    constructor(itenNr, naam , prijs, url){
        this._itemNr = itenNr;
        this._naam = naam;
        this._prijs = prijs;
        this._url = url;
    }

    getItemNr(){
        return this._itemNr;
    }
    getnaam(){
        return this._naam;
    }
    getprijs(){
        return this._prijs;
    }
    getItemurl(){
        return this._url;
    }

    MakeDiv(){
        var li = document.createElement("li");
        var dif = document.createElement("div");
        li.appendChild(dif);
        var nr = document.createElement("p");
        var nrNr = document.createTextNode(this.getItemNr());
        nr.appendChild(nrNr);
        dif.appendChild(nr);

        return li;
    }
}