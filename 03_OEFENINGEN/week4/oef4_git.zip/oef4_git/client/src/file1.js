const but1 = document.getElementById("btn_1");
const but2 = document.getElementById("btn_2");

but1.addEventListener("click" funct)