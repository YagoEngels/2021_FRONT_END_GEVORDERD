import express from "express";
import ToDoClass from "./../shared/ToDoClasse.js"
import bodyParser from "body-parser";

const app = express();
const port = 3000;

app.use(express.static("../client/public"));
app.use(bodyParser.json());

let todo = new ToDoClass()

let todoItems = [];

app.get("/api/todo", (req,res) => {
    
});

app.post("/api/todo", (req,res) => {
    
});

app.put("/api/todo", (req,res) => {
    

});

app.delete("/api/todo", (req,res) => {
    
});

app.listen(port, function(){
    console.log(`er is beweging op port ${port}`);
});