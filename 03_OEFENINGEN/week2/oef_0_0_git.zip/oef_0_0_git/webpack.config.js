// webpack.config.js 
module.exports = {
    entry: {
        main: './src/index.js'
    },
    output: {
        filename: '../wwwroot/main.js'
    }
};
