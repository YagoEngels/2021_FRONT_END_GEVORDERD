console.log("ejooo");


document.getElementById("leeg").innerHTML = `
<form>
    <label for = 'iets'>Iets</label>
    <input type= 'text' id='iets'/>
</form>`