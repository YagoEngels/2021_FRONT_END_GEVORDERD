import { winkelItem } from "./file1Class";
const array = [];
array.push(new winkelItem)
var li = document.createElement("li");
var b = document.createTextNode("ojoj");
li.appendChild(b);
document.getElementById("mid").append(ul);